//toggle
let show = document.getElementById("show-ul");
let nav = document.getElementById("nav");
show.onclick = function () {
    nav.classList.toggle("show");
}